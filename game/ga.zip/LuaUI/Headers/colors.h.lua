--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--
--  file:    colors.h.lua
--  brief:   color strings (Spring format) and color arrays
--  author:  goddot info@bitopsy.com
--
--  Copyright (C) 2007.
--  Licensed under the terms of the GNU GPL, v2 or later.
--
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

WhiteStr   = "\255\255\255\255"
BlackStr   = "\255\001\001\001"
GreyStr    = "\255\128\128\128"
RedStr     = "\255\255\001\001"
PinkStr    = "\255\255\064\064"
GreenStr   = "\255\001\255\001"
BlueStr    = "\255\001\001\255"
CyanStr    = "\255\001\255\255"
YellowStr  = "\255\255\255\001"
MagentaStr = "\255\255\001\255"

Colors = {}
Colors.white   = { 1.0, 1.0, 1.0, 1.0 }
Colors.black   = { 0.0, 0.0, 0.0, 1.0 }
Colors.grey    = { 0.5, 0.5, 0.5, 1.0 }
Colors.red     = { 1.0, 0.0, 0.0, 1.0 }
Colors.green   = { 0.0, 1.0, 0.0, 1.0 }
Colors.blue    = { 0.0, 0.0, 1.0, 1.0 }
Colors.yellow  = { 1.0, 1.0, 0.0, 1.0 }
Colors.cyan    = { 0.0, 1.0, 1.0, 1.0 }
Colors.magenta = { 1.0, 0.0, 1.0, 1.0 }
